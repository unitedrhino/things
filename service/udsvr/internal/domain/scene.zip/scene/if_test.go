package scene

//func TestTrigger(t1 *testing.T) {
//	do := If{
//		Type:  SceneTypeAuto,
//		Timer: Timers{&Timer{ExecAt: 123, ExecRepeat: 0b1111111}, &Timer{ExecAt: 223, ExecRepeat: 0b1111111}},
//	}
//	text, _ := json.Marshal(do)
//	fmt.Println(string(text))
//}
